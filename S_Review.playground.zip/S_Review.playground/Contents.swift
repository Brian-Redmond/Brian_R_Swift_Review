/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var Actor = "Benedict Cumberbatch"
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
var name = "Brian Redmond"
print(name)
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
let a = 3
let b = 10
let c = 7
let d = 4.5
let e = 9.0
let f = 2.8
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/

/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
print(a + b)
print(c + a)
print(d + f)
print(e + d)
print(d - f)
print(b / c)
print(e * f)
/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"

/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
    if temperature > 80 { print("It is hot outside. Be sure to wear shorts")
    } else { print("It's a bit chilly outside, be sure to wear jeans")}
    if raining { true
        print("be sure to bring a umbrella")} else
    {print("no need for a umbrella")}
    if time == "Morning" { print("go to school") }
    else {"Afternoon"; print("Go home"); "Night"; print("go to sleep") }
/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for count in 1...10{ print("\(count)")}
var count2 = 1;
while count2 < 11 {
    print ("\(count2)")
    count2 = count2 + 1
}
/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
    
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
    
/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
var closure = {
    (num1: Int, num2: Int ) in
    print(num1 - num2)
}
closure(7,9)
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum Names: String, CaseIterable{
case name1 = "Jack"
case name2 = "Jerry"
case name3 = "Brian"
}
var Firstname = Names.name2
switch Firstname {
case .name1,.name3:
    print("Happy Birthday,\(Names.name3.rawValue)")
default:
    print("Happy Birthday")
}
/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
struct Name {
   var FirstName: String
    var SecondName: String
    var Lastname: String
    
    init(strFirst: String, strMiddle: String, strLast: String){
    self.FirstName = strFirst
        self.SecondName = strMiddle
        self.Lastname = strLast
    }
}
    var Names2 = Name(strFirst:"Brian", strMiddle: "B", strLast: "Redmond")
print("Good Morning! My name is \(Names2.FirstName) \(Names2.SecondName) \(Names2.Lastname) ")
/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
class Coffee {
    var CupSize1: CupSize
    var isCaffine: Bool
    var hasCream: Bool
    var hasSugar: Bool

    enum CupSize: String, CaseIterable{
        case small = "S"
        case medium = "M"
        case large = "L"
        case extralarge = "XL"
    }
    init(incSize:CupSize, isCaffin:Bool, hasCream: Bool, hassugar:Bool) {
        self.CupSize1 = incSize
        self.isCaffine = isCaffin
        self.hasCream = hasCream
        self.hasSugar = hassugar
}
    func printeverything(){
        print("The cup size of my coffee is \(CupSize1.rawValue)")
        if isCaffine {
            print("Has Caffine")
        } else {
            print("No energy juice")}
        
            if hasSugar {
            print("It has sugar")
        }else{
                print("No sugary stuff")}
                
            if hasCream {
                print("It has smooth whipped stuff")
            }else{
                print("No smooth whipped stuff")}
            

}
}
var StarbucksCoffee = Coffee(incSize:.extralarge, isCaffin: true, hasCream: true, hassugar: true )
StarbucksCoffee.printeverything()
